Enclave Flight Jacket

Small Mod by Tagaziel

1.0 Overview

This small mod adds an Enclave flight jacket into the game (along with an Enclave Air Force cap), available from three places they logically would be available from. Features light protection and a charismatic look. 

2.0 Installation

Just extract the contents into your FNV/data folder

3.0 Contact

If you want to drop me a line, comment or send an e-mail to mikaelgrizzly@gmail.com