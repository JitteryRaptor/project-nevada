Rusty Metal Armor 1.1
by vampirecosmonaut
----------------------------------------

Added Rusty elements to the metal armor and retextured the helmet to be much darker.
Now the metal armor loks like it's seen some serious use by a wastelander.


Installation
----------------------------------------

1) Extract the "texture" folder to "data" in your fallout3 folder. Make sure not to overwrite any other custom textures.

2) Copy "archiveinvalidation.txt" into the root of fallout3. If you already have that file, just open it up and copy over the text to the existing.


Version history
----------------------------------------

1.0) Rusty Metal and Helmet retexture
1.1) Improved Specular Lighting Map on Helmet



Contact
----------------------------------------
vampirecosmonaut on Fallout3Nexus


Legal
----------------------------------------
Please personal message me if you wish to use this in a different mod.
This is not to be used in any for profit mod.