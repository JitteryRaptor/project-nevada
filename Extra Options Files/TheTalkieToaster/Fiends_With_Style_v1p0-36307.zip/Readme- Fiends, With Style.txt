Fiends, With Style v1.0, by Talkie Toaster

-----------
DESCRIPTION
-----------
FWS adds stylish (?) raider vault suits to the Fiends. That's it. Well, they do live in Vault 3.

-----
USAGE
-----
Copy the contents of the folder to New Vegas\Data, and check the ESM in the launcher's Data Files section.

The raider vault suits can be repaired with Vault Suits and Raider Armour (and each other).

-------
CREDITS
-------
Made by me. Feel free to use the meshes in your own work, with credit.

---------
CHANGELOG
---------
1.0-	Release