using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using fomm.Scripting;
 
class Script : BaseScript
{
    public static bool install;
    public static Form InstallForm;
    public static PictureBox BackgroundPicture;
    public static PictureBox VersionPicture;
    public static Panel InstallPanel;
    public static Button InstallButton;
    public static Button CancelInstallButton;
	
	public static bool IsPluginActive(String pluginName)
	{
	    string[] loadOrder = GetActivePlugins();
	    for (int i = 0; i < loadOrder.Length; ++i)
	    {
	        if (loadOrder[i].Equals(pluginName, StringComparison.InvariantCultureIgnoreCase))
	             return true;
	    }
	    return false;
	}
	public static int GetPluginIndex(String pluginName)
	{
	    string[] loadOrder = GetAllPlugins();
	    for (int i = 0; i < loadOrder.Length; ++i)
	    {
	        if (loadOrder[i].Equals(pluginName, StringComparison.InvariantCultureIgnoreCase))
	            return i;
	    }
	    return -1;
	}
	public static void PlaceAtPlugin(String targetPlugin, String pluginToMove, int offset)
	{
	    int targetPluginIndex = GetPluginIndex(targetPlugin);
	    int pluginToMoveIndex = GetPluginIndex(pluginToMove);
	    if (targetPluginIndex != -1 && pluginToMoveIndex != -1)
	    {
	        int[] pluginIdxArray = { pluginToMoveIndex };
	        SetLoadOrder(pluginIdxArray, targetPluginIndex + offset);
	    }
	}	
	public static void PlaceAfterPlugin(String targetPlugin, String pluginToMove)
	{
    	PlaceAtPlugin(targetPlugin, pluginToMove, 1);
	}
	public static void PlaceBeforePlugin(String targetPlugin, String pluginToMove)
	{
	    PlaceAtPlugin(targetPlugin, pluginToMove, 0);
	}	
    
    public static Image GetImageFromFomod(string filename)
    {
        byte[] data = GetFileFromFomod(filename);
        MemoryStream s = new MemoryStream(data);
        Image img = Image.FromStream(s);
        s.Close();
        return img;
    }
    public static void CreateInstallForm()
    {
        InstallForm = CreateCustomForm();
 
        // customize install form
        InstallForm.FormBorderStyle = FormBorderStyle.Fixed3D;
        InstallForm.StartPosition = FormStartPosition.CenterScreen;
        InstallForm.Size = new Size(500, 600);
        // place background picture box
        BackgroundPicture = new PictureBox();
        BackgroundPicture.Location = new Point(0, 0);
        BackgroundPicture.Size = new Size(500, 600);
        // load picture file from .fomod and stream into picture box
//        BackgroundPicture.Image = GetImageFromFomod("fomod/UNARMenu.png");
       	if(IsPluginActive("FO3 Wanderers Edition - Main File.esp"))
		{	BackgroundPicture.Image = GetImageFromFomod("fomod/FWEVersion.png");	}
   		else
		{	BackgroundPicture.Image = GetImageFromFomod("fomod/VanillaVersion.png");	}
        // add BackgroundPicture to list of controls
        InstallForm.Controls.Add(BackgroundPicture);
        // load picture file from .fomod and stream into picture box
        
/*        VersionPicture = new PictureBox();
        VersionPicture.Location = new Point(0, 0);
        VersionPicture.Size = new Size(500, 600);
       	if(IsPluginActive("FO3 Wanderers Edition - Main File.esp"))
    	    { VersionPicture.Image = GetImageFromFomod("fomod/FWEVersion.png"); }
   		else
    	    { VersionPicture.Image = GetImageFromFomod("fomod/VanillaVersion.png"); }

        InstallForm.Controls.Add(VersionPicture);
*/
        // install button
        InstallButton = new Button();
        InstallButton.Text = "Install";
        InstallButton.BackColor = Color.Silver;
        InstallButton.Location = new Point(120, 495);
        InstallButton.Size = new Size(100, 23);

        // cancel button
        CancelInstallButton = new Button();
        CancelInstallButton.Text = "Cancel";
        CancelInstallButton.BackColor = Color.Silver;
        CancelInstallButton.Location = new Point(280, 495);
        CancelInstallButton.Size = new Size(100, 23);

        // build form
        BackgroundPicture.Controls.Add(InstallButton);
        BackgroundPicture.Controls.Add(CancelInstallButton);
        
        AttachHandlers();
    }
    public static void AttachHandlers()
    {
        //Attach a handler that will fire when the apply button is clicked
        InstallButton.Click += delegate(object sender, EventArgs args)
        {
            install = true;
            InstallForm.Close();
        };
        CancelInstallButton.Click += delegate(object sender, EventArgs args)
        {
            install = false;
            InstallForm.Close();
        };
    }
    public static bool OnActivate()
    {
        CreateInstallForm();
        InstallForm.ShowDialog();
        if(install)
        {
            PerformBasicInstall();
        
        	if(IsPluginActive("Fallout3.esm"))
        	{
    			PlaceAfterPlugin("Fallout3.esm", "tubunarVanilla.esp");
	           	SetPluginActivation("tubunarFWE.esp", false);
    		}
        	if(IsPluginActive("FO3 Wanderers Edition - Main File.esp"))
        	{
    			PlaceAfterPlugin("FO3 Wanderers Edition - Main File.esp", "tubunarFWE.esp");
	           	SetPluginActivation("tubunarFWE.esp", true);
    	       	SetPluginActivation("tubunarVanilla.esp", false);
    		}
        }
        return install;
    }
}