Service Carbine by Soldier9501

*** REQUIRES HONEST HEARTS DLC ***
*** Non-dlc version available, see below ***

file directory:
ServiceCarbine.esp
ServiceCarbine_Lite.esp
meshes/weapons/2handautomatic/ServiceCarbine.nif
textures/weapons/2handautomatic/ServiceCarbine.dds
textures/weapons/2handautomatic/ServiceCarbine_n.dds
textures/weapons/2handautomatic/1stPersonServiceCarbine.dds
textures/weapons/2handautomatic/1stPersonServiceCarbine_n.dds

Meshes: 
	- taken from vanilla New Vegas and modified/spliced by myself
Texture: 
	- Base texture is from a custom "This Machine" retexture created by Piestub. Modified for use by me.
	- Several textures were also taken from vanilla New Vegas.

This adds a carbine rifle chambered for pistol rounds called the "Service Carbine." I created it to use .45 Auto rounds,
so it currently requires Honest Hearts. It should also be affected by the "Grunt" perk.

2 of the rifles are located at Ranger Substation Osprey in Zion Canyon.
Base ID: xx000ADE

ServiceCarbine_Lite:
	- does not require any DLC, uses .357 magnum rounds.
	- currently not placed in the game world, must be obtained via console
	- has not been tested